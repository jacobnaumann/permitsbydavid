// In Contact.js

import React from 'react';
import Header from '../common/Header';

const Contact = () => {
  return (
    <div>
        Contact Page Content
    </div>
  );
};

export default Contact;