//Services.js

import React from 'react';
import Header from '../common/Header'; // Make sure the path is correct

const Services = () => {
  return (
    <div>
        Services Page Content
    </div>
  );
};

export default Services;